# Module: github-cli-workflows

> Part of the `coding-workflow` skill. Paths below are relative to this module folder (`modules/github-cli-workflows/`).
> Original trigger scope: Interact with GitHub through an already available `gh` CLI using focused issue, pull-request, CI-run, and API workflows. Use when the user explicitly wants GitHub CLI commands or a CLI-focused workflow; do not install tooling or replace the maintained GitHub plugin automatically. Turkish triggers: GitHub repo/issue/PR/release işlemi, gh ile kontrol et, GitHub'da yayınla.

# GitHub Skill

Use the `gh` CLI to interact with GitHub. Always specify `--repo owner/repo` when not in a git directory, or use URLs directly.

## Pull Requests

Check CI status on a PR:

```bash
gh pr checks 55 --repo owner/repo
```

List recent workflow runs:

```bash
gh run list --repo owner/repo --limit 10
```

View a run and see which steps failed:

```bash
gh run view <run-id> --repo owner/repo
```

View logs for failed steps only:

```bash
gh run view <run-id> --repo owner/repo --log-failed
```

## API for Advanced Queries

The `gh api` command is useful for accessing data not available through other subcommands.

Get PR with specific fields:

```bash
gh api repos/owner/repo/pulls/55 --jq '.title, .state, .user.login'
```

## JSON Output

Most commands support `--json` for structured output. You can use `--jq` to filter:

```bash
gh issue list --repo owner/repo --json number,title --jq '.[] | "\(.number): \(.title)"'
```
